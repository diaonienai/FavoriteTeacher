CREATE TRIGGER votes_insert_after_trigger
  AFTER INSERT
  ON votes
  FOR EACH ROW
  BEGIN 
  UPDATE teacher SET votes = votes + 1 WHERE teacher_no = new.teacher_no;
  UPDATE institute SET ins_votes = ins_votes + 1 
  WHERE ins_no = (SELECT ins_no FROM teacher WHERE teacher_no = new.teacher_no);
END;

